### [@coreui/angular-pro](https://coreui.io/angular/) changelog

---

#### `4.5.5`

- fix(multi-select): missing destroyRef
- chore(dependencies): update

---

#### `4.5.4`

- fix(filter-input.directive): missing destroyRef
- fix(multi-select-option): missing destroyRef
- feat(multi-select): loading prop
- fix(tooltip): add IntersectionObserver to remove tooltip when host element is not visible
- chore(dependencies): update

---

#### `4.5.1`

- fix(multi-select): single select reset to initial value after search and select with virtualScroller
- chore(dependencies): update

---

#### `4.4.12`

- fix(multi-select): single select reset to initial value after search and select
- chore(dependencies): update

---

#### `4.5.0`

- chore: dependencies update
  - `Angular 16`
  - `TypeScript ~4.9.3`
- refactor(breadcrumb-router.service): router.events takeUntilDestroyed()
- refactor(toaster): remove ComponentFactoryResolver

---

#### `4.4.11`

- fix(smart-table-head): reorder html for column label and sorter for use with `.text-truncate`
- chore(dependencies): update

---

#### `4.4.10`

- feat(calendar): show/select adjacent days in month view
- fix(date-range-picker): rangesButtonsSize default value & type
- fix(date-range-picker): input values update, inputEndHoverValue cleanup
- chore(peerDependencies): update `@coreui/coreui-pro` to `~4.5.0`
- chore(dependencies): update

---

#### `4.4.9`

- refactor: safe ?.unsubscribe() from subscriptions
- chore(dependencies): update

---

#### `4.4.8`

- refactor(tabs): safe tabServiceSubscription?.unsubscribe()
- chore(dependencies): update

---

#### `4.4.7`

- feat(form-check): add reverse prop
- chore(dependencies): update

---

#### `4.4.6`

- perf(calendar): skip check when no params for isDateInRangeDisabled() and isDateDisabled()
- chore(dependencies): update

---

#### `4.4.5`

- feat(smart-table): add tableCustomHeader template

---

#### `4.4.4`

- fix(multi-select): initially selected options tags not rendered
- fix(smart-table): ITableHeaderCellProps interface update
- chore(dependencies): update

---

#### `4.4.3`

- fix(calendar): disabledDates type
- fix(date-range-picker): disabled attr for input not working
- chore(dependencies): update

---

#### `4.4.1`
 
- fix(alert): typo in template
- refactor(html-attr): cleanup
- refactor(icon, icon-set): cleanup

---

#### `4.4.0`

- feat: standalone components
- fix(date-range-picker): infinite loop on fast input date range changes
- chore: dependencies update
- chore(sidebar): minor cleanups

---

#### `4.4.0-next.1`

- feat: standalone components
- chore: dependencies update
- fix(popover): remove popover when host element is not visible

---

#### `4.3.18`

- `@coreui/angular-pro`
  - feat(multi-select): virtualScroller
  - feat(multi-select): custom SearchFn

---

#### `4.3.17`

- `@coreui/angular`
- `@coreui/angular-chartjs`
- `@coreui/icons-angular`
  - chore: dependencies update

---

#### `4.3.16`

- `@coreui/angular-pro`
  - feat(smart-table): custom column filter functions in columns config
  - feat(smart-table): custom column sorter functions in columns config
  - chore: dependencies update
- `@coreui/angular-chartjs`
  - chore: dependencies update
- `@coreui/icons-angular`
  - feat(cIcon): standalone directive
  - chore: dependencies update

---

#### `4.3.15`

- fix(multi-select): reactive forms initial value cleared before options init
- chore: dependencies update
- `@coreui/angular-chartjs`
  - feat(c-chart): emit chartRef on new Chart()
  - feat(c-chart): standalone component

---

#### `4.3.14`

- feat(multi-select): add `search: 'external'`, `searchValueChange`, `visibleOptions`, `onTouched`, refactor
- refactor(multi-select-option): changeDetection onPush, cleanups and rewrites with rxjs
  - add `Id` prop, with default generated Id
  - add `role option`
  - `space` keydown preventDefault
  - add `exportAs: cMultiSelectOption` 
- refactor(multi-select-optgroup-label): changeDetection OnPush, cleanup
- fix(smart-table-filter): filter-input directive destroy$.complete()
- chore: dependencies update

---

#### `4.4.0-next.0`

- feat: standalone components (wip) 

---

#### `4.3.13`

- fix(multi-select): scroll for overflow-y only
 
---

#### `4.3.12`

- fix(multi-select): single select - check value against array

---

#### `4.3.11`

- fix(multi-select): single select - remove aggressive focus on first render
- fix(multi-select-option): avoid selection when dropdown not visible
- fix(offcanvas): avoid flicker on the first render

---

#### `4.3.10`

- feat(offcanvas): add responsive variations
- refactor(offcanvas): animation classes, scrollbar behavior, cleanup
- refactor(modal, offcanvas): move get scrollbarWidth to BackdropService
- feat(offcanvas): add backdrop static option support
- chore: dependencies update

---

#### `4.3.8`

- fix(dropdown): visibleChange emit and visibleState update on changes, refactor with rxjs
- feat(date-picker, date-range-picker): closeOnSelect prop to close dropdown after value setting
- refactor(multi-select-tag): multiselectVisible$ subscription with async pipe, simplified with rxjs

---

#### `4.3.7`

- fix(smart-table): add sorterValue differ
- fix(smart-table): add autocomplete off for filter inputs
- chore: update to: `Angular 15.1`

---

#### `4.3.6`

- fix(time-picker): add visual validation feedback, `valid` prop, focus/blur behavior, refactor
- fix(date-range-picker): add visual validation feedback, `valid` prop
- fix(multi-select): add visual validation feedback, `valid` prop

---

#### `4.3.5`

- fix(sidebar): open behavior on mobile layout change, refactor

---

#### `4.3.4`

- refactor(smart-table): extract table and column filter-input

---

#### `4.3.3`

- fix(sidebar): emit visible event on mobile layout change

---

#### `4.3.2`

- refactor(smart-table-filter): rewrite to observables and OnPush
- refactor(smart-table): items-per-page-selector
- fix(smart-table): tableFilterValue should update not only on firstChange
- fix(smart-table): columnSorter prop not passed to smart-table-head
- refactor(toaster): remove deprecated ComponentFactoryResolver

---

#### `4.3.1`

- fix(multi-select): selected options update fails on component value reset

---

#### `4.3.0`

update to:
- `Angular 15`
- `TypeScript 4.8`
- `RxJS 7.5`
    
---
