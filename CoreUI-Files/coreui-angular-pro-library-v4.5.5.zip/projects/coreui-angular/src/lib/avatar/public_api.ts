export { AvatarComponent } from './avatar.component';
export { AvatarModule } from './avatar.module';
