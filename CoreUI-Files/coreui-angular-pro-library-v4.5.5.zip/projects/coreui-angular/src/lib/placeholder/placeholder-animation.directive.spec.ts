import { PlaceholderAnimationDirective } from './placeholder-animation.directive';

describe('PlaceholderAnimationDirective', () => {
  it('should create an instance', () => {
    const directive = new PlaceholderAnimationDirective();
    expect(directive).toBeTruthy();
  });
});
