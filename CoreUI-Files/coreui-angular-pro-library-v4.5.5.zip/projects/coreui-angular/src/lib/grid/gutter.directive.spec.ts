import { GutterDirective } from './gutter.directive';

describe('GutterDirective', () => {
  it('should create an instance', () => {
    const directive = new GutterDirective();
    expect(directive).toBeTruthy();
  });
});
