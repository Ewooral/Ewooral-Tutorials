import { ColDirective } from './col.directive';

describe('ColDirective', () => {
  it('should create an instance', () => {
    const directive = new ColDirective();
    expect(directive).toBeTruthy();
  });
});
