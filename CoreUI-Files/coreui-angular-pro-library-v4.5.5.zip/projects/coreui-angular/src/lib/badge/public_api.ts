export { BadgeComponent } from './badge.component';
export { BadgeModule } from './badge.module';
