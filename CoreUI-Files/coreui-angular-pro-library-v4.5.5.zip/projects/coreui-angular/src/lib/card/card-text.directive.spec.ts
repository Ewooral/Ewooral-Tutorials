import { CardTextDirective } from './card-text.directive';

describe('CardTextDirective', () => {
  it('should create an instance', () => {
    const directive = new CardTextDirective();
    expect(directive).toBeTruthy();
  });
});
