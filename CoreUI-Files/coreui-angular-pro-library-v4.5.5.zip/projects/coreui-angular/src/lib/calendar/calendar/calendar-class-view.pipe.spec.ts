import { CalendarClassViewPipe } from './calendar-class-view.pipe';

describe('CalendarClassViewPipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarClassViewPipe();
    expect(pipe).toBeTruthy();
  });
});
