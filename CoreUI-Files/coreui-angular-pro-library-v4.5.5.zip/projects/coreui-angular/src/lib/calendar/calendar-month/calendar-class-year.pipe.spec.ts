import { CalendarClassYearPipe } from './calendar-class-year.pipe';

describe('CalendarClassYearPipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarClassYearPipe();
    expect(pipe).toBeTruthy();
  });
});
