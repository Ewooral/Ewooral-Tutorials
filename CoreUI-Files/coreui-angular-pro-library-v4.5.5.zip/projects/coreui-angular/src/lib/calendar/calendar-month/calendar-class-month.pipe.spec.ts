import { CalendarClassMonthPipe } from './calendar-class-month.pipe';

describe('CalendarClassMonthPipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarClassMonthPipe();
    expect(pipe).toBeTruthy();
  });
});
