import { CalendarDayPipe } from './calendar-day.pipe';

describe('CalendarDayPipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarDayPipe();
    expect(pipe).toBeTruthy();
  });
});
