import { FormLabelDirective } from './form-label.directive';

describe('LabelDirective', () => {
  it('should create an instance', () => {
    const directive = new FormLabelDirective();
    expect(directive).toBeTruthy();
  });
});
