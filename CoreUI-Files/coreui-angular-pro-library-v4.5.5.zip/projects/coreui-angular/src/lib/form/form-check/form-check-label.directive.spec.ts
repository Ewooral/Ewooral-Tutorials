import { FormCheckLabelDirective } from './form-check-label.directive';

describe('FormCheckLabelDirective', () => {
  it('should create an instance', () => {
    const directive = new FormCheckLabelDirective();
    expect(directive).toBeTruthy();
  });
});
