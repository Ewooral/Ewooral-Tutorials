import { ListGroupDirective } from './list-group.directive';

describe('ListGroupDirective', () => {
  it('should create an instance', () => {
    const directive = new ListGroupDirective();
    expect(directive).toBeTruthy();
  });
});
