import { AlertHeadingDirective } from './alert-heading.directive';

describe('AlertHeadingDirective', () => {
  it('should create an instance', () => {
    const directive = new AlertHeadingDirective();
    expect(directive).toBeTruthy();
  });
});
