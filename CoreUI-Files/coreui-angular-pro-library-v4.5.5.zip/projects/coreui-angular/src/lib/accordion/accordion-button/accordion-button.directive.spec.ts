import { AccordionButtonDirective } from './accordion-button.directive';

describe('AccordionButtonDirective', () => {
  it('should create an instance', () => {
    const directive = new AccordionButtonDirective();
    expect(directive).toBeTruthy();
  });
});
