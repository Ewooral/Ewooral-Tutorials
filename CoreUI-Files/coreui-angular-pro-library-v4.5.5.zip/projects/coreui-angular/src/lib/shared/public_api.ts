export { SharedModule } from './shared.module';
export { HtmlAttributesDirective } from './html-attr.directive';
export { TemplateIdDirective } from './template-id.directive';
