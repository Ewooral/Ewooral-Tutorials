/*
 * Public API Surface of coreui-angular-chartjs
 */

export * from './lib/chartjs.component';
export * from './lib/chartjs.module';
