import { App } from 'vue'
import { CSmartPagination } from './CSmartPagination'

const CSmartPaginationPlugin = {
  install: (app: App): void => {
    app.component(CSmartPagination.name, CSmartPagination)
  },
}

export { CSmartPaginationPlugin, CSmartPagination }
