import { App } from 'vue'
import { CElementCover } from './CElementCover'

const CElementCoverPlugin = {
  install: (app: App): void => {
    app.component(CElementCover.name, CElementCover)
  },
}

export { CElementCoverPlugin, CElementCover }
