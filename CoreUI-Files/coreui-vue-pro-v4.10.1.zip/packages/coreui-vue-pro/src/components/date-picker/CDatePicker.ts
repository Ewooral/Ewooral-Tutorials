import { defineComponent, h, PropType } from 'vue'

import { CDateRangePicker } from '../date-range-picker/'

import { Color } from '../props'

const CDatePicker = defineComponent({
  name: 'CDatePicker',
  props: {
    /**
     * Default date of the component
     */
    calendarDate: {
      type: [Date, String],
    },
    /**
     * Toggle visibility or set the content of cancel button.
     */
    cancelButton: {
      type: [Boolean, String],
      default: 'Cancel',
    },
    /**
     * Sets the color context of the cancel button to one of CoreUI’s themed colors.
     *
     * @values 'primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark', 'light'
     */
    cancelButtonColor: {
      ...Color,
      default: 'primary',
    },
    /**
     * Size the cancel button small or large.
     *
     * @values 'sm', 'lg'
     */
    cancelButtonSize: {
      type: String,
      default: 'sm',
      validator: (value: string) => {
        return ['sm', 'lg'].includes(value)
      },
    },
    /**
     * Set the cancel button variant to an outlined button or a ghost button.
     *
     * @values 'ghost', 'outline'
     */
    cancelButtonVariant: {
      type: String,
      default: 'ghost',
      validator: (value: string) => {
        return ['ghost', 'outline'].includes(value)
      },
    },
    /**
     * Toggle visibility of the cleaner button.
     */
    cleaner: {
      type: Boolean,
      default: true,
    },
    /**
     * Toggle visibility or set the content of confirm button.
     */
    confirmButton: {
      type: [Boolean, String],
      default: 'OK',
    },
    /**
     * Sets the color context of the confirm button to one of CoreUI’s themed colors.
     *
     * @values 'primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark', 'light'
     */
    confirmButtonColor: {
      ...Color,
      default: 'primary',
    },
    /**
     * Size the confirm button small or large.
     *
     * @values 'sm', 'lg'
     */
    confirmButtonSize: {
      type: String,
      default: 'sm',
      validator: (value: string) => {
        return ['sm', 'lg'].includes(value)
      },
    },
    /**
     * Set the confirm button variant to an outlined button or a ghost button.
     *
     * @values 'ghost', 'outline'
     */
    confirmButtonVariant: {
      type: String,
      validator: (value: string) => {
        return ['ghost', 'outline'].includes(value)
      },
    },
    /**
     * Set the format of day name.
     *
     * @default 'numeric'
     * @since 4.6.0
     */
    dayFormat: {
      type: [Function, String],
      default: 'numeric',
      required: false,
      validator: (value: string) => {
        if (typeof value === 'string') {
          return ['numeric', '2-digit'].includes(value)
        }
        if (typeof value === 'function') {
          return true
        }
        if (typeof value === 'function') {
          return true
        }
        return false
      },
    },
    /**
     * Toggle the disabled state for the component.
     */
    disabled: Boolean,
    /**
     * Specify the list of dates that cannot be selected.
     */
    disabledDates: {
      type: Array as PropType<Date[] | Date[][]>,
    },
    /**
     * Initial selected date.
     */
    date: {
      type: [Date, String],
      required: false,
    },
    /**
     * Sets the day of start week.
     * - 0 - Sunday,
     * - 1 - Monday,
     * - 2 - Tuesday,
     * - 3 - Wednesday,
     * - 4 - Thursday,
     * - 5 - Friday,
     * - 6 - Saturday,
     */
    firstDayOfWeek: {
      type: Number,
      default: 1,
    },
    /**
     * Set date format.
     * We use date-fns to format dates. Visit https://date-fns.org/v2.28.0/docs/format to check accepted patterns.
     */
    format: String,
    /**
     * Toggle visibility of footer element or set the content of footer.
     */
    footer: Boolean,
    /**
     * The id global attribute defines an identifier (ID) that must be unique in the whole document.
     *
     * The name attribute for the input element is generated based on the `id` property:
     * - {id}-date
     */
    id: String,
    /**
     * Toggle visibility or set the content of the input indicator.
     */
    indicator: {
      type: Boolean,
      default: true,
    },
    /**
     * Toggle the readonly state for the component.
     */
    inputReadOnly: Boolean,
    /**
     * Sets the default locale for components. If not set, it is inherited from the navigator.language.
     */
    locale: {
      type: String,
      default: 'default',
    },
    /**
     * Max selectable date.
     */
    maxDate: {
      type: [Date, String],
    },
    /**
     * Min selectable date.
     */
    minDate: {
      type: [Date, String],
    },
    /**
     * Show arrows navigation.
     */
    navigation: {
      type: Boolean,
      default: true,
    },
    /**
     * Reorder year-month navigation, and render year first.
     *
     * @since 4.6.0
     */
    navYearFirst: Boolean,
    /**
     * Specifies a short hint that is visible in the input.
     */
    placeholder: {
      type: String,
      default: 'Select date',
    },
    /**
     * Set whether days in adjacent months shown before or after the current month are selectable. This only applies if the `showAdjacementDays` option is set to true.
     *
     * @since 4.9.0
     */
    selectAdjacementDays: Boolean,
    /**
     * Set whether to display dates in adjacent months (non-selectable) at the start and end of the current month.
     *
     * @since 4.9.0
     */
    showAdjacementDays: {
      type: Boolean,
      default: true,
    },
    /**
     * Size the component small or large.
     *
     * @values 'sm', 'lg'
     */
    size: {
      type: String,
      required: false,
      validator: (value: string) => {
        return ['sm', 'lg'].includes(value)
      },
    },
    /**
     * Provide an additional time selection by adding select boxes to choose times.
     */
    timepicker: Boolean,
    /**
     * Set length or format of day name.
     *
     * @type  number | 'long' | 'narrow' | 'short'
     */
    weekdayFormat: {
      type: [Function, Number, String],
      default: 2,
      validator: (value: string | number) => {
        if (typeof value === 'string') {
          return ['long', 'narrow', 'short'].includes(value)
        }
        if (typeof value === 'number') {
          return true
        }
        if (typeof value === 'function') {
          return true
        }
        return false
      },
    },
  },
  emits: [
    /**
     * Callback fired when the date changed.
     *
     * @property {Date} date - date object
     * @property {string} formatedDate - formated date
     */
    'date-change',
    /**
     * Callback fired when the date changed.
     *
     * @property {Date | null} date - date object
     * @since 4.7.0
     */
    'update:date',
  ],
  setup(props, { emit }) {
    return () =>
      h(CDateRangePicker, {
        calendars: 1,
        onStartDateChange: (date: Date, formatedDate: string) => {
          emit('date-change', date, formatedDate)
          emit('update:date', date)
        },
        range: false,
        startDate: props.date,
        ...props,
      })
  },
})

export { CDatePicker }
