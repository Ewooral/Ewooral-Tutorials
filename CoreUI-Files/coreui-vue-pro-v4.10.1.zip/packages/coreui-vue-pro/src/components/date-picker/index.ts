import { App } from 'vue'
import { CDatePicker } from './CDatePicker'

const CDatePickerPlugin = {
  install: (app: App): void => {
    app.component(CDatePicker.name, CDatePicker)
  },
}

export { CDatePickerPlugin, CDatePicker }
