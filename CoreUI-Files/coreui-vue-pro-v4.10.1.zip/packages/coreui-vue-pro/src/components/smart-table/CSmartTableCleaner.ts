import { defineComponent, h } from 'vue'

const CSmartTableCleaner = defineComponent({
  name: 'CSmartTableCleaner',
  props: {
    isFiltered: {
      type: String,
      default: undefined,
      required: false,
    },
  },
  emits: ['tableCleanerClick'],
  setup(props, { emit, slots }) {
    const handleClick = () => {
      emit('tableCleanerClick')
    }

    return () =>
      h(
        'button',
        {
          type: 'button',
          class: 'btn btn-transparent',
          ...(!props.isFiltered && { disabled: true, tabIndex: -1 }),
          onClick: handleClick,
        },
        slots.cleanerIcon && slots.cleanerIcon(),
      )
  },
})

export { CSmartTableCleaner }
