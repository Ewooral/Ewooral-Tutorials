import { computed, defineComponent, h, ref, PropType, watch, onMounted } from 'vue'

import { cilArrowTop, cilArrowBottom, cilFilterX, cilSwapVertical } from '@coreui/icons'
import { CIcon } from '@coreui/icons-vue'

import { CElementCover } from '../element-cover'
import { CFormInput, CFormLabel, CFormSelect } from '../form'
import { CSmartPagination } from '../smart-pagination'
import { CTable, CTableDataCell, CTableFoot, CTableRow } from '../table'

import { CSmartTableBody } from './CSmartTableBody'
import { CSmartTableHead } from './CSmartTableHead'

import { isObjectInArray } from '../../utils'

import {
  filterColumns,
  filterTable,
  getColumnNames,
  getColumnNamesFromItems,
  isSortable,
  sortItems,
} from './utils'

import type {
  Column,
  ColumnFilter,
  ColumnFilterValue,
  Item,
  ItemsPerPageSelect,
  FooterItem,
  Pagination,
  Sorter,
  SorterValue,
  TableFilter,
} from './types'

const CSmartTable = defineComponent({
  name: 'CSmartTable',
  props: {
    /**
     * Sets active page. If 'pagination' prop is enabled, activePage is set only initially.
     */
    activePage: {
      type: Number,
      default: 1,
    },
    /**
     * When set, displays table cleaner above table, next to the table filter (or in place of table filter if `tableFilter` prop is not set)
     * Cleaner resets `tableFilterValue`, `columnFilterValue`, `sorterValue`. If clean is possible it is clickable (`tabIndex="0"` `role="button"`, `color="danger"`), otherwise it is not clickable and transparent. Cleaner can be customized through the `cleanerIcon` slot.
     *
     */
    cleaner: Boolean,
    /**
     * Style table items as clickable.
     */
    clickableRows: Boolean,
    /**
     * When set, displays additional filter row between table header and items, allowing filtering by specific column.
     * Column filter can be customized, by passing prop as object with additional options as keys. Available options:
     * - external (Boolean) - Disables automatic filtering inside component.
     * - lazy (Boolean) - Set to true to trigger filter updates only on change event.
     */
    columnFilter: {
      type: [Boolean, Object] as PropType<boolean | ColumnFilter>,
    },
    /**
     * Value of table filter. To set pass object where keys are column names and values are filter strings e.g.:
     * { user: 'John', age: 12 }
     */
    columnFilterValue: {
      type: Object as PropType<ColumnFilterValue>,
    },
    /**
     * Prop for table columns configuration. If prop is not defined, table will display columns based on the first item keys, omitting keys that begins with underscore (e.g. '_props')
     *
     * In columns prop each array item represents one column. Item might be specified in two ways:
     * String: each item define column name equal to item value.
     * Object: item is object with following keys available as column configuration:
     * - key (required)(String) - define column name equal to item key.
     * - filter (Boolean) - removes filter from column when set to false.
     * - label (String) - define visible label of column. If not defined, label will be generated automatically based on column name, by converting kebab-case and snake_case to individual words and capitalization of each word.
     * - sorter (Boolean) - disables sorting of the column when set to false
     * - [_props](https://coreui.io/vue/docs/components/table.html#ctableheadercell) (String/Array/Object) - add props to `CTableHeaderCell`.
     * - _style (String/Array/Object) - adds styles to the column header (useful for defining widths)
     */
    columns: {
      type: Array as PropType<(Column | string)[]>,
    },
    /**
     * Enables table sorting by column value. Sorting will be performed corectly only if values in column are of one type: string (case insensitive) or number.
     *
     * Sorter can be customized, by passing prop as object with additional options as keys. Available options:
     * - external (Boolean) - Disables automatic sorting inside component.
     * - resetable (Boolean) - If set to true clicking on sorter have three states: ascending, descending and null. That means that third click on sorter will reset sorting, and restore table to original order.
     */
    columnSorter: {
      type: [Boolean, Object] as PropType<boolean | Sorter>,
    },
    /**
     * If `true` Displays table footer, which mirrors table header. (without column filter).
     * Or Array of objects or strings, where each element represents one cell in the table footer.
     *
     * Example items:
     * `['FooterCell', 'FooterCell', 'FooterCell']`
     * or
     * `[{ label: 'FooterCell', _props: { color: 'success' }, ...]`
     */
    footer: {
      type: [Boolean, Array] as PropType<boolean | (FooterItem | string)[]>,
    },
    /**
     * Set to false to remove table header.
     */
    header: {
      type: Boolean,
      default: true,
    },
    /**
     * Array of objects, where each object represents one item - row in table. Additionally, you can customize each row by passing them by [_props](http://coreui.io/vue/docs/components/table.html#ctablerow) key and single cell by [_cellProps](http://coreui.io/vue/docs/components/table.html#ctabledatacell).
     *
     * Examples:
     * - `_props: { color: 'primary', align: 'middle'}`
     * - `_cellProps: { all: { class: 'fw-semibold'}, 'name': { color: 'info' }}`
     */
    items: {
      type: Array as PropType<Item[]>,
      default: () => [],
    },
    /**
     * The total number of items. Use if you pass a portion of data from an external source to let know component what is the total number of items.
     *
     * @since 4.8.0
     */
    itemsNumber: Number,
    /**
     * Number of items per site, when pagination is enabled.
     */
    itemsPerPage: {
      type: Number,
      default: 10,
    },
    /**
     * Label for items per page selector.
     */
    itemsPerPageLabel: {
      type: String,
      default: 'Items per page:',
    },
    /**
     * Items per page selector options.
     */
    itemsPerPageOptions: {
      type: Array as PropType<number[]>,
      default: () => [5, 10, 20, 50],
    },
    /**
     * Adds select element over table, which is used for control items per page in pagination. If you want to customize this element, pass object with optional values:
     * - label (String) - replaces default label text
     * - values (Array) - custom array of pagination values
     * - external (Boolean) - disables automatic 'itemsPerPage' change (use to change pages externaly by 'pagination-change' event).
     */
    itemsPerPageSelect: {
      type: [Boolean, Object] as PropType<boolean | ItemsPerPageSelect>,
    },
    /**
     * When set, table will have loading style: loading spinner and reduced opacity. When 'small' prop is enabled spinner will be also smaller.
     */
    loading: Boolean,
    /**
     * ReactNode or string for passing custom noItemsLabel texts.
     */
    noItemsLabel: {
      type: String,
      default: 'No items found',
    },
    /**
     * Enables default pagination. Set to true for default setup or pass an object with additional CPagination props. Default pagination will always have the computed number of pages that cannot be changed. The number of pages is generated based on the number of passed items and 'itemsPerPage' prop. If this restriction is an obstacle, you can make external CPagination instead.
     */
    pagination: {
      type: [Boolean, Object] as PropType<boolean | Pagination>,
    },
    /**
     * Properties to [CSmartPagination](https://coreui.io/vue/docs/components/smart-pagination#csmartpagination) component.
     */
    paginationProps: Object,
    /**
     * Add checkboxes to make table rows selectable.
     */
    selectable: Boolean,
    /**
     * Enables select all checkbox displayed in the header of the table.
     *
     * Can be customized, by passing prop as object with additional options as keys. Available options:
     * - external (Boolean) - Disables automatic selection inside the component.
     *
     * @since 4.8.0
     */
    selectAll: {
      type: [Boolean, Object] as PropType<boolean | { external?: boolean }>,
    },
    /**
     * Array of selected objects, where each object represents one item - row in table.
     *
     * Example item: `{ name: 'John' , age: 12 }`
     *
     * @since 4.8.0
     */
    selected: {
      type: Array as PropType<Item[]>,
      default: () => [],
    },
    /**
     * State of the sorter. Name key is column name, direction can be 'asc' or 'desc'. eg.:
     * { column: 'status', state: 'asc' }
     */
    sorterValue: {
      type: Object as PropType<SorterValue>,
    },
    /**
     * Properties to [CTableBody](https://coreui.io/vue/docs/components/table/#ctablebody) component.
     */
    tableBodyProps: Object,
    /**
     * Properties to [CTableFoot](https://coreui.io/vue/docs/components/table/#ctablefoot) component.
     */
    tableFootProps: Object,
    /**
     * When set, displays table filter above table, allowing filtering by specific column.
     *
     * Column filter can be customized, by passing prop as object with additional options as keys. Available options:
     * - external (Boolean) - Disables automatic filtering inside component.
     * - lazy (Boolean) - Set to true to trigger filter updates only on change event.
     */
    tableFilter: {
      type: [Boolean, Object] as PropType<boolean | TableFilter>,
    },
    /**
     * The element represents a caption for a component.
     */
    tableFilterLabel: {
      type: String,
      default: 'Filter:',
    },
    /**
     * Specifies a short hint that is visible in the search input.
     */
    tableFilterPlaceholder: {
      type: String,
      default: 'type string...',
    },
    /**
     * Value of table filter.
     */
    tableFilterValue: String,
    /**
     * Properties to [CTableHead](https://coreui.io/vue/docs/components/table/#ctablehead) component.
     */
    tableHeadProps: Object,
    /**
     * Properties to [CTable](https://coreui.io/vue/docs/components/table/#ctable) component.
     */
    tableProps: Object,
  },
  emits: [
    /**
     * Page change callback.
     *
     * @property {number} page - active page number
     */
    'activePageChange',
    /**
     * Column filter change callback.
     *
     * @property {object} ColumnFilterValue {[key: string]: string | number}
     */
    'columnFilterChange',
    /**
     * Filtered items change callback.
     *
     * @property {array} items
     */
    'filteredItemsChange',
    /**
     * Pagination change callback.
     *
     * @property {number} itemsPerPageNumber - items per page number
     */
    'itemsPerPageChange',
    /**
     * Row click callback.
     *
     * @property {object} item
     * @property {number} index
     * @property {string} columnName
     * @property {event} event
     */
    'rowClick',
    /**
     * Select all callback.
     *
     * @since 4.8.0
     */
    'selectAll',
    /**
     * Selected items change callback.
     *
     * @property {array} items
     */
    'selectedItemsChange',
    /**
     * Sorter value change callback.
     *
     * @property {object} SorterValue { column?: string, state?: number | string}
     */
    'sorterChange',
    /**
     * Table filter change callback.
     *
     * @property {string} tableFilterValue
     */
    'tableFilterChange',
  ],
  setup(props, { emit, slots }) {
    const activePage = ref(props.activePage)
    const columnFilterState = ref<ColumnFilterValue>(props.columnFilterValue ?? {})
    const items = ref<Item[]>(
      props.items.map((item: Item, index: number) => {
        return { ...item, _id: index }
      }),
    )
    const itemsNumber = ref(props.itemsNumber)
    // eslint-disable-next-line unicorn/explicit-length-check
    const itemsPerPage = ref<number>(props.itemsPerPage || items.value.length)
    const selected = ref<Item[]>([])
    const selectedAll = ref<boolean | string>()
    const sorterState = ref<SorterValue>(props.sorterValue || {})
    const tableFilterState = ref(props.tableFilterValue ?? '')

    watch(
      () => props.activePage,
      () => {
        activePage.value = props.activePage
      },
    )

    watch(
      () => props.columnFilterValue,
      () => {
        if (props.columnFilterValue) {
          columnFilterState.value = props.columnFilterValue
        }
      },
    )

    watch(
      () => props.items,
      () => {
        if (
          props.items &&
          props.items.length < itemsPerPage.value * activePage.value - itemsPerPage.value
        ) {
          activePage.value = 1
        }

        props.items.forEach((item: Item) => {
          if (item._selected) {
            const _item = { ...item }
            delete _item['_cellProps']
            delete _item['_props']
            delete _item['_selected']

            selected.value = [...selected.value, _item]
          }
        })

        if (Array.isArray(props.items)) {
          items.value = props.items
          // eslint-disable-next-line unicorn/explicit-length-check
          itemsNumber.value = props.itemsNumber || props.items.length
        }
      },
      {
        immediate: true,
      },
    )

    watch(
      () => props.itemsNumber,
      () => {
        itemsNumber.value = props.itemsNumber
      },
    )

    watch(
      () => props.itemsPerPage,
      () => {
        itemsPerPage.value = props.itemsPerPage
      },
    )

    watch(
      () => props.selected,
      () => {
        selected.value = props.selected
      },
    )

    watch(
      () => props.sorterValue,
      () => {
        if (props.sorterValue) {
          sorterState.value = props.sorterValue
        }
      },
    )

    watch(itemsPerPage, () => {
      if (props.itemsPerPage !== itemsPerPage.value) {
        activePage.value = 1 // TODO: set proper page after _itemsPerPage update
      }

      emit('itemsPerPageChange', itemsPerPage.value)
    })

    watch(
      [selected, itemsNumber],
      () => {
        if (props.selectable) {
          emit('selectedItemsChange', selected)

          if (selected.value.length === itemsNumber.value) {
            selectedAll.value = true
            return
          }

          if (selected.value.length === 0) {
            selectedAll.value = false
            return
          }

          if (selected.value.length > 0 && selected.value.length !== itemsNumber.value) {
            selectedAll.value = 'indeterminate'
          }
        }
      },
      {
        immediate: true,
      },
    )

    onMounted(() => {
      if (
        items.value &&
        items.value.length < itemsPerPage.value * activePage.value - itemsPerPage.value
      ) {
        activePage.value = 1
      }
    })

    const handleSorterChange = (column: string, index: number) => {
      if (
        !isSortable(
          index,
          props.columns,
          props.columnSorter,
          itemsDataColumns.value,
          columnNames.value,
        )
      ) {
        return
      }

      //if column changed or sort was descending change asc to true
      const state = sorterState.value

      if (state.column === column) {
        if (state.state === 0) {
          state.state = 'asc'
        } else if (state.state === 'asc') {
          state.state = 'desc'
        } else {
          if (typeof props.columnSorter === 'object' && !props.columnSorter.resetable) {
            state.state = 'asc'
          } else {
            state.state = 0
          }
        }
      } else {
        state.column = column
        state.state = 'asc'
      }

      sorterState.value.column = state.column
      sorterState.value.state = state.state

      emit('sorterChange', sorterState.value)
    }

    const handleActivePageChange = (page: number) => {
      activePage.value = page
      emit('activePageChange', page)
    }

    const handleItemsPerPageChange = (event: Event) => {
      if (
        typeof props.itemsPerPageSelect !== 'object' ||
        (typeof props.itemsPerPageSelect === 'object' && !props.itemsPerPageSelect.external)
      ) {
        itemsPerPage.value = Number((event.target as HTMLSelectElement).value)
      }
    }

    const handleRowChecked = (item: Item, value: boolean) => {
      if (value && !isObjectInArray(selected.value, item, ['_cellProps', '_props', '_selected'])) {
        selected.value = [...selected.value, item]
        return
      }

      selected.value = selected.value.filter(
        (_item: Item) => !isObjectInArray([_item], item, ['_cellProps', '_props', '_selected']),
      )
    }

    const handleSelectAllChecked = () => {
      if (selectedAll.value === true) {
        selected.value = []
        return
      }

      emit('selectAll')

      if (props.selectAll && typeof props.selectAll === 'object' && props.selectAll.external) {
        return
      }

      selected.value = items.value.map((item) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { _cellProps, _props, _selected, ...rest } = item
        return rest
      })
    }

    const handleColumnFilterChange = (colName: string, value: any, type?: string) => {
      const _isLazy =
        props.columnFilter &&
        typeof props.columnFilter === 'object' &&
        props.columnFilter.lazy === true
      if ((_isLazy && type === 'input') || (!_isLazy && type === 'change')) {
        return
      }

      activePage.value = 1
      columnFilterState.value = { ...columnFilterState.value, [`${colName}`]: value }

      emit('columnFilterChange', columnFilterState.value)
    }

    const handleTableFilterChange = (value: string, type: string) => {
      const _isLazy =
        props.columnFilter &&
        typeof props.columnFilter === 'object' &&
        props.columnFilter.lazy === true
      if ((_isLazy && type === 'input') || (!_isLazy && type === 'change')) {
        return
      }

      activePage.value = 1
      tableFilterState.value = value

      emit('tableFilterChange', tableFilterState.value)
    }

    const handleClean = () => {
      tableFilterState.value = ''
      columnFilterState.value = {}
      sorterState.value = {}
    }

    const columnNames = computed(() => getColumnNames(props.columns, items.value))

    const itemsDataColumns = computed(() =>
      columnNames.value.filter((name) => getColumnNamesFromItems(items.value).includes(name)),
    )

    const filteredColumns = computed(() =>
      filterColumns(
        items.value,
        props.columnFilter,
        columnFilterState.value,
        itemsDataColumns.value,
      ),
    )

    const filteredTable = computed(() =>
      filterTable(
        filteredColumns.value,
        props.tableFilter,
        tableFilterState.value,
        itemsDataColumns.value,
      ),
    )

    const sortedItems = computed(() =>
      sortItems(props.columnSorter, filteredTable.value, itemsDataColumns.value, sorterState.value),
    )

    const numberOfPages = computed(() =>
      itemsPerPage.value ? Math.ceil(sortedItems.value.length / itemsPerPage.value) : 1,
    )

    const firstItemOnActivePageIndex = computed(() =>
      activePage.value ? (activePage.value - 1) * itemsPerPage.value : 0,
    )

    const currentItems = computed(() =>
      activePage.value
        ? sortedItems.value.slice(
            firstItemOnActivePageIndex.value,
            firstItemOnActivePageIndex.value + itemsPerPage.value,
          )
        : sortedItems.value,
    )

    return () =>
      h('div', {}, [
        (props.tableFilter || props.cleaner) &&
          h(
            'div',
            {
              class: 'row my-2 mx-0',
            },
            [
              props.tableFilter &&
                h(
                  'div',
                  {
                    class: 'col-auto p-0',
                  },
                  props.tableFilter &&
                    h(
                      'div',
                      {
                        class: 'row mb-2',
                      },
                      {
                        default: () => [
                          h(
                            CFormLabel,
                            {
                              class: 'col-sm-auto col-form-label',
                            },
                            {
                              default: () => props.tableFilterLabel,
                            },
                          ),
                          h(
                            'div',
                            {
                              class: 'col-sm-auto',
                            },
                            h(CFormInput, {
                              onInput: (e) => {
                                handleTableFilterChange(
                                  (e.target as HTMLInputElement).value,
                                  'input',
                                )
                              },
                              onChange: (e) => {
                                handleTableFilterChange(
                                  (e.target as HTMLInputElement).value,
                                  'change',
                                )
                              },
                              placeholder: props.tableFilterPlaceholder,
                              value: tableFilterState.value,
                            }),
                          ),
                        ],
                      },
                    ),
                ),
              props.cleaner &&
                h(
                  'div',
                  {
                    class: 'col-auto p-0',
                  },
                  h(
                    'button',
                    {
                      type: 'button',
                      class: 'btn btn-transparent',
                      ...(!(
                        tableFilterState.value ||
                        sorterState.value.column ||
                        Object.values(columnFilterState.value).join('')
                      ) && { disabled: true, tabIndex: -1 }),
                      onClick: () => handleClean(),
                      onKeydown: (event: KeyboardEvent) => {
                        if (event.key === 'Enter') handleClean()
                      },
                    },
                    slots.cleanerIcon
                      ? slots.cleanerIcon()
                      : h(CIcon, { width: '18', content: cilFilterX }),
                  ),
                ),
            ],
          ),
        h(
          'div',
          {
            class: 'position-relative',
          },
          {
            default: () => [
              h(
                CTable,
                {
                  ...props.tableProps,
                },
                {
                  default: () => [
                    props.header &&
                      h(
                        CSmartTableHead,
                        {
                          component: 'head',
                          ...props.tableHeadProps,
                          columnFilter: props.columnFilter,
                          columnFilterValue: columnFilterState.value,
                          columns: props.columns ?? columnNames.value,
                          columnSorter: props.columnSorter,
                          items: items.value,
                          selectable: props.selectable,
                          selectAll: props.selectAll,
                          selectedAll: selectedAll.value,
                          sorterState: sorterState.value,
                          onCustomFilterChange: (key: string, value: any) =>
                            handleColumnFilterChange(key, value),
                          onFilterInput: (key: string, value: string) =>
                            handleColumnFilterChange(key, value, 'input'),
                          onFilterChange: (key: string, value: string) =>
                            handleColumnFilterChange(key, value, 'change'),
                          onSelectAllChecked: () => handleSelectAllChecked(),
                          onSortClick: (key: string, index: number) =>
                            handleSorterChange(key, index),
                        },
                        {
                          // @slot Sorter icon when items are unsorted.
                          sortingIcon: () =>
                            slots.sortingIcon
                              ? slots.sortingIcon()
                              : h('svg', {
                                  xmlns: 'http://www.w3.org/2000/svg',
                                  class: 'icon',
                                  viewBox: '0 0 512 512',
                                  role: 'img',
                                  innerHTML: cilSwapVertical[1],
                                }),
                          // @slot Sorter icon when items are sorted ascending.
                          sortingIconAscending: () =>
                            slots.sortingIconAscending
                              ? slots.sortingIconAscending()
                              : h('svg', {
                                  xmlns: 'http://www.w3.org/2000/svg',
                                  class: 'icon',
                                  viewBox: '0 0 512 512',
                                  role: 'img',
                                  innerHTML: cilArrowBottom[1],
                                }),
                          // @slot  Sorter icon when items are sorted descending.
                          sortingIconDescending: () =>
                            slots.sortingIconDescending
                              ? slots.sortingIconDescending()
                              : h('svg', {
                                  xmlns: 'http://www.w3.org/2000/svg',
                                  class: 'icon',
                                  viewBox: '0 0 512 512',
                                  role: 'img',
                                  innerHTML: cilArrowTop[1],
                                }),
                        },
                      ),
                    h(CSmartTableBody, {
                      clickableRows: props.clickableRows,
                      columnNames: columnNames.value,
                      currentItems: currentItems.value,
                      firstItemOnActivePageIndex: firstItemOnActivePageIndex.value,
                      noItemsLabel: props.noItemsLabel,
                      onRowChecked: (item: Item, value: boolean) => handleRowChecked(item, value),
                      onRowClick: (
                        item: Item,
                        index: number,
                        columnName: string,
                        event: MouseEvent | boolean,
                      ) => props.clickableRows && emit('rowClick', item, index, columnName, event),
                      scopedSlots: slots,
                      selectable: props.selectable,
                      selected: selected.value,
                      ...props.tableBodyProps,
                    }),
                    typeof props.footer === 'boolean' &&
                      props.footer &&
                      h(CSmartTableHead, {
                        component: 'footer',
                        ...props.tableFootProps,
                        columnFilter: false,
                        columnSorter: false,
                        columns: props.columns ? props.columns : columnNames.value,
                        selectable: props.selectable,
                        selectAll: props.selectAll,
                        selectedAll: selectedAll.value,
                        showGroups: false,
                        onSelectAllChecked: () => handleSelectAllChecked(),
                      }),
                    Array.isArray(props.footer) &&
                      h(
                        CTableFoot,
                        {
                          ...props.tableFootProps,
                        },
                        {
                          default: () =>
                            h(
                              CTableRow,
                              {},
                              {
                                default: () => [
                                  Array.isArray(props.footer) &&
                                    props.footer.map((item: FooterItem | string) =>
                                      h(
                                        CTableDataCell,
                                        {
                                          ...(typeof item === 'object' &&
                                            item._props && { ...item._props }),
                                        },
                                        {
                                          default: () =>
                                            typeof item === 'object' ? item.label : item,
                                        },
                                      ),
                                    ),
                                ],
                              },
                            ),
                        },
                      ),
                  ],
                },
              ),
              props.loading &&
                h(
                  CElementCover,
                  {
                    boundaries: [
                      { sides: ['top'], query: 'tbody' },
                      { sides: ['bottom'], query: 'tbody' },
                    ],
                  },
                  {
                    // @slot elementCover.
                    ...(slots.elementCover && {
                      default: () => slots.elementCover && slots.elementCover(),
                    }),
                  },
                ),
            ],
          },
        ),
        (props.pagination || props.itemsPerPageSelect) &&
          h(
            'div',
            {
              class: 'row',
            },
            [
              h(
                'div',
                {
                  class: 'col',
                },
                (props.pagination && numberOfPages.value > 1) || props.paginationProps
                  ? h(CSmartPagination, {
                      pages: numberOfPages.value,
                      activePage: activePage.value,
                      ...props.paginationProps,
                      onActivePageChange: (page) =>
                        typeof props.pagination === 'object' && props.pagination.external
                          ? emit('activePageChange', page)
                          : handleActivePageChange(page),
                    })
                  : '',
              ),
              props.itemsPerPageSelect &&
                h(
                  'div',
                  {
                    class: 'col-auto ms-auto',
                  },
                  h(
                    'div',
                    {
                      class: 'row',
                    },
                    {
                      default: () => [
                        h(
                          CFormLabel,
                          {
                            class: 'col-auto col-form-label',
                          },
                          {
                            default: () => props.itemsPerPageLabel,
                          },
                        ),
                        h(
                          'div',
                          {
                            class: 'col-auto',
                          },
                          h(
                            CFormSelect,
                            {
                              value: itemsPerPage.value,
                              onChange: handleItemsPerPageChange,
                            },
                            {
                              default: () =>
                                props.itemsPerPageOptions &&
                                props.itemsPerPageOptions.map((number, index) => {
                                  return h(
                                    'option',
                                    {
                                      value: number,
                                      key: index,
                                    },
                                    number,
                                  )
                                }),
                            },
                          ),
                        ),
                      ],
                    },
                  ),
                ),
            ],
          ),
      ])
  },
})
export { CSmartTable }
