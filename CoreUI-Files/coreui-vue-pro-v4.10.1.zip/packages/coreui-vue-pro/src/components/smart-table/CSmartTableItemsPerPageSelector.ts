import { defineComponent, h, PropType } from 'vue'

import { CFormLabel } from '../form/CFormLabel'
import { CFormSelect } from '../form/CFormSelect'

const CSmartTableItemsPerPageSelector = defineComponent({
  name: 'CSmartTableItemsPerPageSelector',
  props: {
    itemsPerPage: {
      type: Number,
      default: undefined,
      require: false,
    },
    itemsPerPageLabel: {
      type: String,
      default: undefined,
      require: false,
    },
    itemsPerPageOptions: {
      type: Array as PropType<number[]>,
      default: () => [],
      require: false,
    },
  },
  emits: ['changeItemsPerPage'],
  setup(props, { emit }) {
    const handleChange = (event: Event) => {
      const target = event.target as HTMLSelectElement
      emit('changeItemsPerPage', Number(target.value))
    }

    return () =>
      h(
        'div',
        {
          class: 'row',
        },
        {
          default: () => [
            h(
              CFormLabel,
              {
                class: 'col-auto col-form-label',
              },
              {
                default: () => props.itemsPerPageLabel,
              },
            ),
            h(
              'div',
              {
                class: 'col-auto',
              },
              h(
                CFormSelect,
                {
                  value: props.itemsPerPage,
                  onChange: handleChange,
                },
                {
                  default: () =>
                    props.itemsPerPageOptions &&
                    props.itemsPerPageOptions.map((number, index) => {
                      return h(
                        'option',
                        {
                          value: number,
                          key: index,
                        },
                        number,
                      )
                    }),
                },
              ),
            ),
          ],
        },
      )
  },
})

export { CSmartTableItemsPerPageSelector }
