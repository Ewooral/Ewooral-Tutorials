/**
 * @ignore
 */
/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/ban-types */
export interface Column {
  filter?: boolean | ((values: any[], onChange: (value: any) => void) => VNode)
  key: string
  label?: string
  sorter?: boolean
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  _style?: any
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  _props?: any
}

import { VNode } from 'vue'

export interface ColumnFilter {
  lazy?: boolean
  external?: boolean
}

export interface ColumnFilterValue {
  [key: string]: number | string | any
}

export type FooterItem = {
  label?: string
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  _props?: any
}

export type Item = {
  [key: string]: number | string | any
  _cellProps?: any
  _props: Object
  _selected: boolean
}

export interface ItemsPerPageSelect {
  external?: boolean
  label?: string
  values?: Array<number>
}

export interface Pagination {
  external?: boolean
}

export interface Sorter {
  resetable?: boolean
  external?: boolean
}

export interface ScopedColumns {
  details?: (a: Item, b: number) => VNode
}

export interface SorterValue {
  column?: string
  state?: number | string
}

export interface TableFilter {
  external?: boolean
  lazy?: boolean
  // TODO: depracated, remove in v5
  label?: string
  // TODO: depracated, remove in v5
  placeholder?: string
}

export interface NoItemsView {
  noResults?: string
  noItems?: string
}
