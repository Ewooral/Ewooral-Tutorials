import { App } from 'vue'
import { CSmartTable } from './CSmartTable'

const CSmartTablePlugin = {
  install: (app: App): void => {
    app.component(CSmartTable.name, CSmartTable)
  },
}

export { CSmartTablePlugin, CSmartTable }
