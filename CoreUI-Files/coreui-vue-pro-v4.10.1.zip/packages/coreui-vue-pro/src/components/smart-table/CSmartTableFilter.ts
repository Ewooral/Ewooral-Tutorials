import { defineComponent, h } from 'vue'
import { CFormLabel } from '../form/CFormLabel'
import { CFormInput } from '../form/CFormInput'

const CSmartTableFilterProps = {
  filterLabel: {
    type: String,
    require: false,
    default: 'Filter:',
  },
  filterPlaceholder: {
    type: String,
    require: false,
    default: 'type string...',
  },
  value: {
    type: [String, Number],
    require: false,
    default: '',
  },
}

const CSmartTableFilter = defineComponent({
  name: 'CSmartTableFilter',
  props: CSmartTableFilterProps,
  emits: ['filterInput', 'filterChange'],
  setup(props, { emit }) {
    const handleFilterInput = (event: Event) => {
      const target = event.target as HTMLInputElement
      emit('filterInput', target.value)
    }

    const handleFilterChange = (event: Event) => {
      const target = event.target as HTMLInputElement
      emit('filterChange', target.value)
    }

    return () =>
      h(
        'div',
        {
          class: 'row mb-2',
        },
        {
          default: () => [
            h(
              CFormLabel,
              {
                class: 'col-sm-auto col-form-label',
              },
              {
                default: () => props.filterLabel,
              },
            ),
            h(
              'div',
              {
                class: 'col-sm-auto',
              },
              h(CFormInput, {
                placeholder: props.filterPlaceholder,
                value: props.value,
                onInput: handleFilterInput,
                onChange: handleFilterChange,
              }),
            ),
          ],
        },
      )
  },
})

export { CSmartTableFilter }
