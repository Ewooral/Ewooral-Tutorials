import { App } from 'vue'
import { CVirtualScroller } from './CVirtualScroller'

const CVirtualScrollerPlugin = {
  install: (app: App): void => {
    app.component(CVirtualScroller.name, CVirtualScroller)
  },
}

export { CVirtualScroller, CVirtualScrollerPlugin }
