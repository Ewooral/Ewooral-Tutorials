import { App } from 'vue'
import { CDateRangePicker } from './CDateRangePicker'

const CDateRangePickerPlugin = {
  install: (app: App): void => {
    app.component(CDateRangePicker.name, CDateRangePicker)
  },
}

export { CDateRangePickerPlugin, CDateRangePicker }
