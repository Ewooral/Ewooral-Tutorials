import { defineComponent, h, PropType } from 'vue'

import type { Option } from './types'

const CMultiSelectSelection = defineComponent({
  name: 'CMultiSelectSelection',
  props: {
    multiple: {
      type: Boolean,
      default: true,
    },
    placeholder: String,
    search: [Boolean, String],
    selected: {
      type: Array as PropType<Option[]>,
      default: () => [],
    },
    selectionType: {
      type: String,
      default: 'tags',
      validator: (value: string) => {
        return ['counter', 'tags', 'text'].includes(value)
      },
    },
    selectionTypeCounterText: {
      type: String,
      default: 'item(s) selected',
    },
  },
  emits: ['remove'],
  setup(props, { emit, slots }) {
    const handleRemove = (option: Option) => {
      emit('remove', option as Option)
    }
    return () =>
      h(
        'div',
        {
          class: 'form-multi-select-selection',
        },
        [
          props.multiple &&
            props.selectionType === 'counter' &&
            !props.search &&
            props.selected.length === 0 &&
            props.placeholder,
          props.multiple &&
            props.selectionType === 'counter' &&
            !props.search &&
            props.selected.length > 0 &&
            `${props.selected.length} ${props.selectionTypeCounterText}`,
          props.multiple &&
            props.selectionType === 'tags' &&
            props.selected.map((option: Option) => {
              if (props.selectionType === 'tags') {
                return h('span', { class: 'form-multi-select-tag' }, [
                  option.text,
                  !option.disabled &&
                    h(
                      'button',
                      {
                        class: 'form-multi-select-tag-delete close',
                        ariaLabel: 'Close',
                        onClick: () => handleRemove(option),
                      },
                      h('span', { ariaHidden: 'true' }, 'x'),
                    ),
                ])
              }
              return
            }),
          props.multiple &&
            props.selectionType === 'text' &&
            props.selected.map((option, index) =>
              h('span', `${option.text}${index === props.selected.length - 1 ? '' : ','}\xA0`),
            ),
          !props.multiple && !props.search && props.selected.map((option) => option.text)[0],
          slots.default && slots.default(),
        ],
      )
  },
})

export { CMultiSelectSelection }
