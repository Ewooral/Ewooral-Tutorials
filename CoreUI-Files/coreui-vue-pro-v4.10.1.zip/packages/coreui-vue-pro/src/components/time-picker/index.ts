import { App } from 'vue'
import { CTimePicker } from './CTimePicker'

const CTimePickerPlugin = {
  install: (app: App): void => {
    app.component(CTimePicker.name, CTimePicker)
  },
}

export { CTimePicker, CTimePickerPlugin }
