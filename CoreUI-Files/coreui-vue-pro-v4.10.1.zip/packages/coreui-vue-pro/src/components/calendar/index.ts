import { App } from 'vue'
import { CCalendar } from './CCalendar'

const CCalendarPlugin = {
  install: (app: App): void => {
    app.component(CCalendar.name, CCalendar)
  },
}

export { CCalendar, CCalendarPlugin }
