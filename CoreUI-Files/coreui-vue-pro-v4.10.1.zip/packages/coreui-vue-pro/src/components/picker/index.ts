import { App } from 'vue'
import { CPicker } from './CPicker'

const CPickerPlugin = {
  install: (app: App): void => {
    app.component(CPicker.name, CPicker)
  },
}

export { CPicker, CPickerPlugin }
