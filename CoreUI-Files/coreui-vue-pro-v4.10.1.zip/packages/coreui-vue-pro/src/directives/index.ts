import vcplaceholder from './v-c-placeholder'
import vcpopover from './v-c-popover'
import vctooltip from './v-c-tooltip'

export { vcplaceholder, vcpopover, vctooltip }
