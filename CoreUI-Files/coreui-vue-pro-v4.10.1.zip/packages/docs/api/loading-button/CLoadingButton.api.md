### CLoadingButton

```jsx
import { CLoadingButton } from '@coreui/vue-pro'
// or
import CLoadingButton from '@coreui/vue-pro/src/components/loading-button/CLoadingButton'
```

#### Props

| Prop name               | Description                                                                                 | Type    | Values               | Default  |
| ----------------------- | ------------------------------------------------------------------------------------------- | ------- | -------------------- | -------- |
| **disabled-on-loading** | Makes button disabled when loading.                                                         | boolean | -                    | -        |
| **loading**             | Loading state (set to true to start animation).                                             | boolean | -                    | false    |
| **spinner-type**        | Sets type of spinner.<br/>`@default` 'border'                                               | string  | `'border'`, `'grow'` | 'border' |
| **timeout**             | Automatically starts loading animation and stops after a determined amount of milliseconds. | number  | -                    | -        |

#### Events

| Event name | Description                                       | Properties |
| ---------- | ------------------------------------------------- | ---------- |
| **click**  | Event called when the user clicks on a component. |
