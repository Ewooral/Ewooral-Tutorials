### CNavGroupItems

```jsx
import { CNavGroupItems } from '@coreui/vue'
// or
import CNavGroupItems from '@coreui/vue/src/components/nav/CNavGroupItems'
```
