### CDropdownDivider

```jsx
import { CDropdownDivider } from '@coreui/vue'
// or
import CDropdownDivider from '@coreui/vue/src/components/dropdown/CDropdownDivider'
```
