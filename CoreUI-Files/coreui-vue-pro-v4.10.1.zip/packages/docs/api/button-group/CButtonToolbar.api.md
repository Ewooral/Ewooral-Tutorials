### CButtonToolbar

```jsx
import { CButtonToolbar } from '@coreui/vue'
// or
import CButtonToolbar from '@coreui/vue/src/components/button-group/CButtonToolbar'
```
