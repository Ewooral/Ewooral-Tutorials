### CInputGroup

```jsx
import { CInputGroup } from '@coreui/vue'
// or
import CInputGroup from '@coreui/vue/src/components/form/CInputGroup'
```

#### Props

| Prop name | Description                        | Type   | Values         | Default |
| --------- | ---------------------------------- | ------ | -------------- | ------- |
| **size**  | Size the component small or large. | string | `'sm'`, `'lg'` | -       |
