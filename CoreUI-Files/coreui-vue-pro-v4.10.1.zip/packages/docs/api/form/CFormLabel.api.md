### CFormLabel

```jsx
import { CFormLabel } from '@coreui/vue'
// or
import CFormLabel from '@coreui/vue/src/components/form/CFormLabel'
```

#### Props

| Prop name             | Description                                                                                               | Type          | Values | Default |
| --------------------- | --------------------------------------------------------------------------------------------------------- | ------------- | ------ | ------- |
| **custom-class-name** | A string of all className you want to be applied to the component, and override standard className value. | array\|string | -      | -       |
