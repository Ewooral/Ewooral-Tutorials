### CFormControl

```jsx
import { CFormControl } from '@coreui/vue'
// or
import CFormControl from '@coreui/vue/src/components/form/CFormControl'
```

### undefined

```jsx
import { undefined } from '@coreui/vue'
// or
import undefined from '@coreui/vue/src/components/form/CFormControl'
```
