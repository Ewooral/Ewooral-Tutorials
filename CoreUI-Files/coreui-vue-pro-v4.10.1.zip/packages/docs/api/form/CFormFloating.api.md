### CFormFloating

```jsx
import { CFormFloating } from '@coreui/vue'
// or
import CFormFloating from '@coreui/vue/src/components/form/CFormFloating'
```
