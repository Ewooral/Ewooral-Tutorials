### CAlertLink

```jsx
import { CAlertLink } from '@coreui/vue'
// or
import CAlertLink from '@coreui/vue/src/components/alert/CAlertLink'
```
