### CHeaderToggler

```jsx
import { CHeaderToggler } from '@coreui/vue'
// or
import CHeaderToggler from '@coreui/vue/src/components/header/CHeaderToggler'
```
