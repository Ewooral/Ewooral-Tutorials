### CHeaderDivider

```jsx
import { CHeaderDivider } from '@coreui/vue'
// or
import CHeaderDivider from '@coreui/vue/src/components/header/CHeaderDivider'
```
