### CHeaderText

```jsx
import { CHeaderText } from '@coreui/vue'
// or
import CHeaderText from '@coreui/vue/src/components/header/CHeaderText'
```
