### CCarouselCaption

```jsx
import { CCarouselCaption } from '@coreui/vue'
// or
import CCarouselCaption from '@coreui/vue/src/components/carousel/CCarouselCaption'
```
