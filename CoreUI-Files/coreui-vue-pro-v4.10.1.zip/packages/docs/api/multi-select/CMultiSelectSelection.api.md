### CMultiSelectSelection

```jsx
import { CMultiSelectSelection } from '@coreui/vue-pro'
// or
import CMultiSelectSelection from '@coreui/vue-pro/src/components/multi-select/CMultiSelectSelection'
```

#### Props

| Prop name | Description | Type | Values | Default |
| --------- | ----------- | ---- | ------ | ------- |

#### Events

| Event name | Description | Properties |
| ---------- | ----------- | ---------- |
| **remove** |             |
