### CMultiSelectOptions

```jsx
import { CMultiSelectOptions } from '@coreui/vue-pro'
// or
import CMultiSelectOptions from '@coreui/vue-pro/src/components/multi-select/CMultiSelectOptions'
```

#### Props

| Prop name | Description | Type | Values | Default |
| --------- | ----------- | ---- | ------ | ------- |

#### Events

| Event name       | Description | Properties |
| ---------------- | ----------- | ---------- |
| **option-click** |             |
