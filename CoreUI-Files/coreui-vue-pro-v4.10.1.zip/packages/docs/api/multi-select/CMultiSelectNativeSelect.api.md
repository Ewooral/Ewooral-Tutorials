### CMultiSelectGroupOption

```jsx
import { CMultiSelectGroupOption } from '@coreui/vue-pro'
// or
import CMultiSelectGroupOption from '@coreui/vue-pro/src/components/multi-select/CMultiSelectNativeSelect'
```

#### Props

| Prop name | Description | Type | Values | Default |
| --------- | ----------- | ---- | ------ | ------- |

#### Events

| Event name | Description | Properties |
| ---------- | ----------- | ---------- |
| **change** |             |
