### CAccordionItem

```jsx
import { CAccordionItem } from '@coreui/vue'
// or
import CAccordionItem from '@coreui/vue/src/components/accordion/CAccordionItem'
```

#### Props

| Prop name    | Description   | Type           | Values | Default |
| ------------ | ------------- | -------------- | ------ | ------- |
| **item-key** | The item key. | number\|string | -      | -       |
