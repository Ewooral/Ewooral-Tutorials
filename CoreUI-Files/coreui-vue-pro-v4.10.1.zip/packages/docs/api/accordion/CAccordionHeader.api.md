### CAccordionHeader

```jsx
import { CAccordionHeader } from '@coreui/vue'
// or
import CAccordionHeader from '@coreui/vue/src/components/accordion/CAccordionHeader'
```
