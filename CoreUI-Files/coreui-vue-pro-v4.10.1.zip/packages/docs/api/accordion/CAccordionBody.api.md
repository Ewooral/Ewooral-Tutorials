### CAccordionBody

```jsx
import { CAccordionBody } from '@coreui/vue'
// or
import CAccordionBody from '@coreui/vue/src/components/accordion/CAccordionBody'
```
