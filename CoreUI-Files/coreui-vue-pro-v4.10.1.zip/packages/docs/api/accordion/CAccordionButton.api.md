### CAccordionButton

```jsx
import { CAccordionButton } from '@coreui/vue'
// or
import CAccordionButton from '@coreui/vue/src/components/accordion/CAccordionButton'
```
