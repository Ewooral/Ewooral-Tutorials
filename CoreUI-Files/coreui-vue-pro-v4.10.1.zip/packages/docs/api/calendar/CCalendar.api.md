### CCalendar

```jsx
import { CCalendar } from '@coreui/vue'
// or
import CCalendar from '@coreui/vue/src/components/calendar/CCalendar'
```

#### Props

| Prop name                                                                 | Description                                                                                                                                                      | Type                 | Values | Default   |
| ------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- | ------ | --------- |
| **calendar-date**                                                         | Default date of the component                                                                                                                                    | date\|string         | -      | -         |
| **calendars**                                                             | The number of calendars that render on desktop devices.                                                                                                          | number               | -      | 1         |
| **day-format** <br><div class="badge bg-primary">4.6.0+</div>             | Set the format of day name.<br/>`@default` 'numeric'                                                                                                             | func\|string         | -      | 'numeric' |
| **disabled-dates**                                                        | Specify the list of dates that cannot be selected.                                                                                                               | Date[] \| Date[][]   | -      | -         |
| **end-date**                                                              | Initial selected to date (range).                                                                                                                                | date\|string         | -      | -         |
| **first-day-of-week**                                                     | Sets the day of start week.<br>- 0 - Sunday,<br>- 1 - Monday,<br>- 2 - Tuesday,<br>- 3 - Wednesday,<br>- 4 - Thursday,<br>- 5 - Friday,<br>- 6 - Saturday,       | number               | -      | 1         |
| **locale**                                                                | Sets the default locale for components. If not set, it is inherited from the navigator.language.                                                                 | string               | -      | 'default' |
| **max-date**                                                              | Max selectable date.                                                                                                                                             | date\|string         | -      | -         |
| **min-date**                                                              | Min selectable date.                                                                                                                                             | date\|string         | -      | -         |
| **navigation**                                                            | Show arrows navigation.                                                                                                                                          | boolean              | -      | true      |
| **nav-year-first** <br><div class="badge bg-primary">4.6.0+</div>         | Reorder year-month navigation, and render year first.                                                                                                            | boolean              | -      | -         |
| **range**                                                                 | Allow range selection.                                                                                                                                           | boolean              | -      | -         |
| **select-end-date**                                                       | Toggle select mode between start and end date.                                                                                                                   | boolean              | -      | -         |
| **select-adjacement-days** <br><div class="badge bg-primary">4.9.0+</div> | Set whether days in adjacent months shown before or after the current month are selectable. This only applies if the `showAdjacementDays` option is set to true. | boolean              | -      | -         |
| **show-adjacement-days** <br><div class="badge bg-primary">4.9.0+</div>   | Set whether to display dates in adjacent months (non-selectable) at the start and end of the current month.                                                      | boolean              | -      | true      |
| **start-date**                                                            | Initial selected date.                                                                                                                                           | date\|string         | -      | -         |
| **weekday-format**                                                        | Set length or format of day name.<br/>`@type` number \| 'long' \| 'narrow' \| 'short'                                                                            | func\|number\|string | -      | 2         |

#### Events

| Event name               | Description                                                 | Properties                          |
| ------------------------ | ----------------------------------------------------------- | ----------------------------------- |
| **calendar-cell-hover**  | Callback fired when the user hovers over the calendar cell. | **date** `Date \| null` - undefined |
| **calendar-date-change** | Callback fired when the calendar date changed.              | **date** `Date \| null` - undefined |
| **start-date-change**    | Callback fired when the start date changed.                 | **date** `Date \| null` - undefined |
| **end-date-change**      | Callback fired when the end date changed.                   | **date** `Date \| null` - undefined |
