### CBackdrop

```jsx
import { CBackdrop } from '@coreui/vue'
// or
import CBackdrop from '@coreui/vue/src/components/backdrop/CBackdrop'
```

#### Props

| Prop name   | Description                               | Type    | Values | Default |
| ----------- | ----------------------------------------- | ------- | ------ | ------- |
| **visible** | Toggle the visibility of modal component. | boolean | -      | false   |
