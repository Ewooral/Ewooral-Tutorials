### CBreadcrumb

```jsx
import { CBreadcrumb } from '@coreui/vue'
// or
import CBreadcrumb from '@coreui/vue/src/components/breadcrumb/CBreadcrumb'
```
