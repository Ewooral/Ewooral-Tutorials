### CCardBody

```jsx
import { CCardBody } from '@coreui/vue'
// or
import CCardBody from '@coreui/vue/src/components/card/CCardBody'
```
