### CCardFooter

```jsx
import { CCardFooter } from '@coreui/vue'
// or
import CCardFooter from '@coreui/vue/src/components/card/CCardFooter'
```
