### CCardGroup

```jsx
import { CCardGroup } from '@coreui/vue'
// or
import CCardGroup from '@coreui/vue/src/components/card/CCardGroup'
```
