### CCardImageOverlay

```jsx
import { CCardImageOverlay } from '@coreui/vue'
// or
import CCardImageOverlay from '@coreui/vue/src/components/card/CCardImageOverlay'
```
