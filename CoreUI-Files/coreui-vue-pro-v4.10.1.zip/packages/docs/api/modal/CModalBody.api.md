### CModalBody

```jsx
import { CModalBody } from '@coreui/vue'
// or
import CModalBody from '@coreui/vue/src/components/modal/CModalBody'
```
