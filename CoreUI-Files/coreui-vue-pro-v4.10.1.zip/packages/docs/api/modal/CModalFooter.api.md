### CModalFooter

```jsx
import { CModalFooter } from '@coreui/vue'
// or
import CModalFooter from '@coreui/vue/src/components/modal/CModalFooter'
```
