### CModalHeader

```jsx
import { CModalHeader } from '@coreui/vue'
// or
import CModalHeader from '@coreui/vue/src/components/modal/CModalHeader'
```

#### Props

| Prop name        | Description                                 | Type    | Values | Default |
| ---------------- | ------------------------------------------- | ------- | ------ | ------- |
| **close-button** | Add a close button component to the header. | boolean | -      | true    |
