<template></template>

<script>
export default {
  mounted() {
    this.$router.push('/getting-started/introduction.html')
  },
}
</script>
