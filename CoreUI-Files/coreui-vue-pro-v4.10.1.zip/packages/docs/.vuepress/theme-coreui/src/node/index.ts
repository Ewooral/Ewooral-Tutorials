import { defaultTheme } from './defaultTheme'

export * from '../shared'
export * from './defaultTheme'
export * from './utils'

export default defaultTheme
