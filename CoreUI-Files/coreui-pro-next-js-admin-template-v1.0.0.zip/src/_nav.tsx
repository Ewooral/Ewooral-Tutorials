import React, { ElementType } from 'react'
import {
  cilBell,
  cilCalculator,
  cilCalendar,
  cilChartPie,
  cilCursor,
  cilDrop,
  cilEnvelopeOpen,
  cilGrid,
  cilLayers,
  cilMap,
  cilNotes,
  cilPencil,
  cilPuzzle,
  cilSpeedometer,
  cilSpreadsheet,
  cilStar,
} from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import { CNavGroup, CNavItem, CNavTitle } from '@coreui/react-pro'

export type Badge = {
  color: string
  text: string
}

export type NavItem = {
  component: string | ElementType
  name: string | JSX.Element
  icon?: string | JSX.Element
  badge?: Badge
  href?: string
  items?: NavItem[]
}

const _nav = [
  {
    component: CNavItem,
    name: 'Dashboard',
    icon: <CIcon icon={cilSpeedometer} customClassName="nav-icon" />,
    badge: {
      color: 'info-gradient',
      text: 'NEW',
    },
    href: '/',
  },
  {
    component: CNavTitle,
    name: 'Theme',
  },
  {
    component: CNavItem,
    name: 'Colors',
    href: '/theme/colors',
    icon: <CIcon icon={cilDrop} customClassName="nav-icon" />,
  },
  {
    component: CNavItem,
    name: 'Typography',
    href: '/theme/typography',
    icon: <CIcon icon={cilPencil} customClassName="nav-icon" />,
  },
  {
    component: CNavTitle,
    name: 'Components',
  },
  {
    component: CNavGroup,
    name: 'Base',
    href: '/components/base',
    icon: <CIcon icon={cilPuzzle} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'Accordion',
        href: '/components/base/accordion',
      },
      {
        component: CNavItem,
        name: 'Breadcrumb',
        href: '/components/base/breadcrumbs',
      },
      {
        component: CNavItem,
        name: 'Cards',
        href: '/components/base/cards',
      },
      {
        component: CNavItem,
        name: 'Carousel',
        href: '/components/base/carousels',
      },
      {
        component: CNavItem,
        name: 'Collapse',
        href: '/components/base/collapses',
      },
      {
        component: CNavItem,
        name: 'List group',
        href: '/components/base/list-groups',
      },
      {
        component: CNavItem,
        name: 'Navs & Tabs',
        href: '/components/base/navs',
      },
      {
        component: CNavItem,
        name: 'Pagination',
        href: '/components/base/paginations',
      },
      {
        component: CNavItem,
        name: 'Placeholders',
        href: '/components/base/placeholders',
      },
      {
        component: CNavItem,
        name: 'Popovers',
        href: '/components/base/popovers',
      },
      {
        component: CNavItem,
        name: 'Progress',
        href: '/components/base/progress',
      },
      {
        component: CNavItem,
        name: 'Spinners',
        href: '/components/base/spinners',
      },
      {
        component: CNavItem,
        name: 'Tables',
        href: '/components/base/tables',
      },
      {
        component: CNavItem,
        name: 'Tooltips',
        href: '/components/base/tooltips',
      },
    ],
  },
  {
    component: CNavGroup,
    name: 'Buttons',
    href: '/components/buttons',
    icon: <CIcon icon={cilCursor} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'Buttons',
        href: '/components/buttons/buttons',
      },
      {
        component: CNavItem,
        name: 'Buttons groups',
        href: '/components/buttons/button-groups',
      },
      {
        component: CNavItem,
        name: 'Dropdowns',
        href: '/components/buttons/dropdowns',
      },
      {
        component: CNavItem,
        name: 'Loading Buttons',
        href: '/components/buttons/loading-buttons',
        badge: {
          color: 'danger-gradient',
          text: 'PRO',
        },
      },
    ],
  },
  {
    component: CNavGroup,
    name: 'Forms',
    href: '/components/forms',
    icon: <CIcon icon={cilNotes} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'Form Control',
        href: '/components/forms/form-control',
      },
      {
        component: CNavItem,
        name: 'Select',
        href: '/components/forms/select',
      },
      {
        component: CNavItem,
        name: 'Multi Select',
        href: '/components/forms/multi-select',
        badge: {
          color: 'danger-gradient',
          text: 'PRO',
        },
      },
      {
        component: CNavItem,
        name: 'Checks & Radios',
        href: '/components/forms/checks-radios',
      },
      {
        component: CNavItem,
        name: 'Range',
        href: '/components/forms/range',
      },
      {
        component: CNavItem,
        name: 'Input Group',
        href: '/components/forms/input-group',
      },
      {
        component: CNavItem,
        name: 'Floating Labels',
        href: '/components/forms/floating-labels',
      },
      {
        component: CNavItem,
        name: 'Date Picker',
        href: '/components/forms/date-picker',
        badge: {
          color: 'danger-gradient',
          text: 'PRO',
        },
      },
      {
        component: CNavItem,
        name: 'Date Range Picker',
        href: '/components/forms/date-range-picker',
        badge: {
          color: 'danger-gradient',
          text: 'PRO',
        },
      },
      {
        component: CNavItem,
        name: 'Time Picker',
        href: '/components/forms/time-picker',
        badge: {
          color: 'danger-gradient',
          text: 'PRO',
        },
      },
      {
        component: CNavItem,
        name: 'Layout',
        href: '/components/forms/layout',
      },
      {
        component: CNavItem,
        name: 'Validation',
        href: '/components/forms/validation',
      },
    ],
  },
  {
    component: CNavGroup,
    name: 'Icons',
    href: '/components/icons',
    icon: <CIcon icon={cilStar} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'CoreUI Free',
        href: '/components/icons/free',
        badge: {
          color: 'success-gradient',
          text: 'FREE',
        },
      },
      {
        component: CNavItem,
        name: 'CoreUI Flags',
        href: '/components/icons/flags',
      },
      {
        component: CNavItem,
        name: 'CoreUI Brands',
        href: '/components/icons/brands',
      },
    ],
  },
  {
    component: CNavGroup,
    name: 'Notifications',
    href: '/components/notifications',
    icon: <CIcon icon={cilBell} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'Alerts',
        href: '/components/notifications/alerts',
      },
      {
        component: CNavItem,
        name: 'Badges',
        href: '/components/notifications/badges',
      },
      {
        component: CNavItem,
        name: 'Modal',
        href: '/components/notifications/modals',
      },
      {
        component: CNavItem,
        name: 'Toasts',
        href: '/components/notifications/toasts',
      },
    ],
  },
  {
    component: CNavItem,
    name: 'Widgets',
    href: '/components/widgets',
    icon: <CIcon icon={cilCalculator} customClassName="nav-icon" />,
    badge: {
      color: 'info-gradient',
      text: 'NEW',
    },
  },
  {
    component: CNavItem,
    name: 'Smart Table',
    icon: <CIcon icon={cilGrid} customClassName="nav-icon" />,
    badge: {
      color: 'danger-gradient',
      text: 'PRO',
    },
    href: '/components/smart-table',
  },
  {
    component: CNavTitle,
    name: 'Plugins',
  },
  {
    component: CNavItem,
    name: 'Calendar',
    icon: <CIcon icon={cilCalendar} customClassName="nav-icon" />,
    badge: {
      color: 'danger-gradient',
      text: 'PRO',
    },
    href: '/plugins/calendar',
  },
  {
    component: CNavItem,
    name: 'Charts',
    icon: <CIcon icon={cilChartPie} customClassName="nav-icon" />,
    href: '/plugins/charts',
  },
  {
    component: CNavItem,
    name: 'Google Maps',
    icon: <CIcon icon={cilMap} customClassName="nav-icon" />,
    badge: {
      color: 'danger-gradient',
      text: 'PRO',
    },
    href: '/plugins/google-maps',
  },
  {
    component: CNavTitle,
    name: 'Extras',
  },
  {
    component: CNavGroup,
    name: 'Pages',
    icon: <CIcon icon={cilStar} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'Login',
        href: '/login',
      },
      {
        component: CNavItem,
        name: 'Register',
        href: '/register',
      },
      {
        component: CNavItem,
        name: 'Error 404',
        href: '/404',
      },
      {
        component: CNavItem,
        name: 'Error 500',
        href: '/500',
      },
    ],
  },
  {
    component: CNavGroup,
    name: 'Apps',
    icon: <CIcon icon={cilLayers} customClassName="nav-icon" />,
    items: [
      {
        component: CNavGroup,
        name: 'Invoicing',
        icon: <CIcon icon={cilSpreadsheet} customClassName="nav-icon" />,
        href: '/apps/invoicing',
        items: [
          {
            component: CNavItem,
            name: 'Invoice',
            badge: {
              color: 'danger-gradient',
              text: 'PRO',
            },
            href: '/apps/invoicing/invoice',
          },
        ],
      },
      {
        component: CNavGroup,
        name: 'Email',
        href: '/apps/email',
        icon: <CIcon icon={cilEnvelopeOpen} customClassName="nav-icon" />,
        items: [
          {
            component: CNavItem,
            name: 'Inbox',
            badge: {
              color: 'danger-gradient',
              text: 'PRO',
            },
            href: '/apps/email/inbox',
          },
          {
            component: CNavItem,
            name: 'Message',
            badge: {
              color: 'danger-gradient',
              text: 'PRO',
            },
            href: '/apps/email/message',
          },
          {
            component: CNavItem,
            name: 'Compose',
            badge: {
              color: 'danger-gradient',
              text: 'PRO',
            },
            href: '/apps/email/compose',
          },
        ],
      },
    ],
  },
]

export default _nav
