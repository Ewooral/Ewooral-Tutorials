import { cilMenu, cilSpeedometer } from '@coreui/icons'

export const iconsSet = Object.assign(
  {},
  {
    cilMenu,
    cilSpeedometer,
  },
)
