import { CSmartPagination } from './CSmartPagination'

export { CSmartPagination }
