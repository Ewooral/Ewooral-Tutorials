import { CLoadingButton } from './CLoadingButton'

export { CLoadingButton }
