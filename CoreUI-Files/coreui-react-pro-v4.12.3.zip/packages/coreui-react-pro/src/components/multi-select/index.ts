import { CMultiSelect } from './CMultiSelect'

export { CMultiSelect }
