import { CAvatar } from './CAvatar'

export { CAvatar }
