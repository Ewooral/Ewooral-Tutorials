import { CSpinner } from './CSpinner'

export { CSpinner }
