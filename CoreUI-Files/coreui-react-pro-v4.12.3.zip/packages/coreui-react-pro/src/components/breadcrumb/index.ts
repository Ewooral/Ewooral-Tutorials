import { CBreadcrumb } from './CBreadcrumb'
import { CBreadcrumbItem } from './CBreadcrumbItem'

export { CBreadcrumb, CBreadcrumbItem }
