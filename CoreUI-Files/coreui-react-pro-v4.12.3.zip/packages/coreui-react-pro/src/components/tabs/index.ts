import { CTabContent } from './CTabContent'
import { CTabPane } from './CTabPane'

export { CTabContent, CTabPane }
